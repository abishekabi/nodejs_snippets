const express = require('express');
const path= require('path')
const app = express();
const port = 8080;

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'))

app.get('/', function(req, res){
  res.send('Home page');
});

app.get('/profile', function(req, res){
  console.log(req.query);
  //var data = { name: 'Abishek', id: '801149643', degree: 'MSCS'}
  res.render('profile', { data: req.query });
});


// app.get('/api/:par', function(req, res){
//   res.send('API param: '+ req.params.par);
// });

app.listen(port, () => console.log(`App listening on port ${port}!`));