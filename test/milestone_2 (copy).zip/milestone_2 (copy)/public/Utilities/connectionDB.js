const Connection = require('./../models/connection');

let self = {};

let categories = ["Tech Meets", "Social Meetups", "IT Seminars", "Empty Category"];

let savedConnections = ['conx_A000001', 'conx_A000005', 'conx_A000006'];
let connections = [];
let conneciton = new Connection();
conneciton.connectionID = "conx_A000001";
conneciton.connectionName = "Pythonistas";
conneciton.category = "Tech Meets";
conneciton.details = "This is a python boot camp for all the pythonistas";
conneciton.location = 'Chicago';
conneciton.date = "2020-05-18T16:00:00Z";
conneciton.thumbnail = "ct_conx_A000001_0001.jpg";
connections.push(conneciton);

conneciton = new Connection();
conneciton.connectionID = "conx_A000002";
conneciton.connectionName = "JSConf";
conneciton.category = "Tech Meets";
conneciton.details = "JavaScript conference for the ones who dig it.";
conneciton.location = 'UNC at Charlotte';
conneciton.date = "2020-03-18T16:00:00Z";
conneciton.thumbnail = "ct_conx_A000002_0001.png";
connections.push(conneciton);

conneciton = new Connection();
conneciton.connectionID = "conx_A000003";
conneciton.connectionName = "DevConf 2020";
conneciton.category = "Tech Meets";
conneciton.details = "A shout out to all those top end devs around the world to get to together and do nothing.";
conneciton.location = 'Las Vegas';
conneciton.date = "2020-02-18T16:00:00Z";
conneciton.thumbnail = "ct_conx_A000003_0001.png";
connections.push(conneciton);

conneciton = new Connection();
conneciton.connectionID = "conx_A000004";
conneciton.connectionName = "International Coffee Hour";
conneciton.category = "Social Meetups";
conneciton.details = "Well yeah, let's have some tea too.";
conneciton.location = 'Detroit';
conneciton.date = "2020-05-18T16:00:00Z";
conneciton.thumbnail = "ct_conx_A000004_0001.png";
connections.push(conneciton);

conneciton = new Connection();
conneciton.connectionID = "conx_A000005";
conneciton.connectionName = "Valentines Karaoke";
conneciton.category = "Social Meetups";
conneciton.details = "For all those singles out there, you rock!!!";
conneciton.location = 'New York';
conneciton.date = "2020-05-18T16:00:00Z";
conneciton.thumbnail = "ct_conx_A000005_0001.jpg";
connections.push(conneciton);

conneciton = new Connection();
conneciton.connectionID = "conx_A000006";
conneciton.connectionName = "Queens Feast";
conneciton.category = "Social Meetups";
conneciton.details = "When you don't want to have a king's meal...";
conneciton.location = 'Andaman';
conneciton.date = "2020-06-18T16:00:00Z";
conneciton.thumbnail = "ct_conx_A000006_0001.jpg";
connections.push(conneciton);

conneciton = new Connection();
conneciton.connectionID = "conx_A000007";
conneciton.connectionName = "Damn! An IT Seminar...";
conneciton.category = "IT Seminars";
conneciton.details = "Look at the name of the connection.";
conneciton.location = 'Mars';
conneciton.date = "2020-09-21T16:00:00Z";
conneciton.thumbnail = "ct_conx_A000007_0001.jpg";
connections.push(conneciton);

self.getCategories = () => {
    return categories;
}

self.getConnectionsByCategory = (category) => {
    return connections.filter(obj => {
        return obj.category === category
    });
}

self.getConnectionsGroupedByCategory = () => {

    let categories = self.getCategories();
    let connections = {};
    let connectionsSize = 0;

    categories.forEach(element => {
        connections[element] = self.getConnectionsByCategory(element);
        connectionsSize+=connections[element].length||0;
    });

    return {connections: connections, length: connectionsSize};
}

self.getSavedConnectionsForUser = (userId) => {

    let savedConnectionDetails = [];

    if(savedConnections.length < 1) {
        return null;
    }

    savedConnections.forEach(element => {
        console.log('here')
        savedConnectionDetails.push(self.getConnectionByID(element));
    });

    return savedConnectionDetails;
}

self.getConnectionByID = (connectionID) => {
    return connections.find(obj => {
        return obj.connectionID === connectionID
    });
}

module.exports = self;