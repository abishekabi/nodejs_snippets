let self = {};

self.validateConnectionID = (connectionID = null) => {
    
    // code to validate connection id
    return true;
}

module.exports = self;