const express = require('express');

const dbConnection = require('./../Utilities/connectionDB');
const helper = require('./../Utilities/helper');

const router = express.Router();

router.get('/', (req, res) => {
    
    result = dbConnection.getConnectionsGroupedByCategory();

    res.render('connections.ejs', { 
        connections: result.connections,
        connectionsSize: result.length,
        user: null
    });
});

router.get('/new', (req, res) => {

    res.render('newConnection.ejs', {user: null});
});

router.post('/new', (req, res) => {
    
    res.redirect('/connections');
});

router.get('/saved', (req, res) => {

    userConnections = dbConnection.getSavedConnectionsForUser("userid");

    res.render('savedConnections.ejs', {
        connections: userConnections,
        user: {userId: 101, userName: "User_007"}
    });
});

router.get('/:connectionID', (req, res) => {

    var connection = null;

    if(req.params && helper.validateConnectionID(req.params.connectionID)) {

        connection = dbConnection.getConnectionByID(req.params.connectionID);
    }

    if(connection) {

        res.render('connection.ejs', { connection: connection, user: null });

    } else {

        res.redirect('/connections/')
    }

});

module.exports = router;