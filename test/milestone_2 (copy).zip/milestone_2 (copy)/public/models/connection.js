class Connection {
    _connectionID = {
        type: String,
        value: null,
        required: true,
        unique: true
    };
    _connectionName = {
        type: String,
        value: null,
        required: true
    };
    _connectionCategory = {
        type: Number,
        value: null,
        required: true
    };
    _details = {
        type: String,
        value: null
    };
    _date = {
        type: 'datetime',
        value: null,
        required: true
    };
    _thumbnail = {
        type: String,
        value: null
    };
    get connectionID () {
        return this._connectionID;
    }
    set connectionID(value) {
        this._connectionID = value;
    }
    get connectionName () {
        return this._connectionName;
    }
    set connectionName(value) {
        this._connectionName = value;
    }
    get connectionCategory () {
        return this._connectionCategory;
    }
    set connectionCategory(value) {
        this._connectionCategory = value;
    }
    get details () {
        return this._details;
    }
    set details(value) {
        this._details = value;
    }
    get date () {
        return this._date;
    }
    set date(value) {
        this._date = value;
    }
    get thumbnail () {
        return this._thumbnail;
    }
    set thumbnail(value) {
        this._thumbnail = value;
    }
}

module.exports = Connection;