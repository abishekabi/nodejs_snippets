const express = require('express');

const index = require('./routes/index');
const connection = require('./routes/connection');
const page_404 = require('./routes/page_404');
const about = require('./routes/about');
const contact = require('./routes/contact');

const port = 8084;
const app = express();

app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));

app.use('/', index);
app.use('/connections/', connection);
app.use('/about', about);
app.use('/contact', contact);
app.use('*', page_404);

app.listen(port);