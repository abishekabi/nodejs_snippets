
const stuff = require('./stuff')

console.log(stuff.mod1);
console.log(stuff.mod2);