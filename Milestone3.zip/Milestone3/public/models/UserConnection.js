
var UserConnection = function(Connection, rsvp) {
    //this.UserID = UserID;
    this.Connection = Connection;
    this.rsvp = rsvp;

    // this.details = function() {
    //     return this.firstName + " " + this.lastName;
    // };
  }



module.exports = UserConnection;

