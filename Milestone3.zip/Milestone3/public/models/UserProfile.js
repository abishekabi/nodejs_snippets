
var UserProfile = function(UserID, UserConnection) {
    this.UserID = UserID;
    this.UserConnection = UserConnection;

    // this.details = function() {
    //     return this.firstName + " " + this.lastName;
    // };
  }



module.exports = UserProfile;

