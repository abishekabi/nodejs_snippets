
module.exports = function(course, title, term, instructor){
    this.CourseID = course;
    this.Title = title;
    this.Term = title;
    this.Instructor = instructor;
}


// var Course = function(course, title, term, instructor){
//     var courseModel = { 'CourseID': course,
//         'Title': title,
//         'Term': title,
//         'Instructor': instructor
//     };
//     return courseModel;
//     };



// export class Course {
//     constructor(course, title, term, instructor) {
        
//         this.CourseID = course;
//         this.Title = title;
//         this.Term = title;
//         this.Instructor = instructor;
//     }

// }

// var cobj = function(){

//     return courseModel
// }
// mycar = new Car("Ford");


// module.exports = Course;
