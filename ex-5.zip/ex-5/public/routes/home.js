module.exports = function(req, res){
    res.send('index');
    };
  